## Source Files

Do not edit icon assets directly (i.e. tweaking those in the "Quintom_Ink" folder with a raster editor)! For ease of development and organization's sake, the sources for all the different icons and cursors are kept in various subfolders: 

 - [cursors](./cursors) contains the source files and render scripts for the cursor theme.
